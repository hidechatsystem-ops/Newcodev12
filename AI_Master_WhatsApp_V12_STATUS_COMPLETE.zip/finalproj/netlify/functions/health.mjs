export default async () => new Response(JSON.stringify({
  ok: true,
  metaConfigured: Boolean(process.env.META_MODEL_API_KEY),
  model: process.env.META_MODEL_NAME || "Llama-4-Maverick-17B-128E-Instruct-FP8",
}), {
  status: 200,
  headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" },
});
