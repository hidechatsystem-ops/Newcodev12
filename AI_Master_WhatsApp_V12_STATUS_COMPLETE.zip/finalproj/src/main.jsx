import React, { useEffect, useMemo, useRef, useState } from "react";
import { createRoot } from "react-dom/client";
import Cropper from "react-easy-crop";
import {
  auth,
  db,
  storage,
  firebaseConfig,
  RecaptchaVerifier,
  signInWithPhoneNumber,
  onAuthStateChanged,
  signOut,
  signInAnonymously,
} from "./firebase";
import { collection, doc, getDoc, getDocs, setDoc, updateDoc, addDoc, query, where, onSnapshot, orderBy, limit, serverTimestamp, writeBatch, deleteDoc } from "firebase/firestore";
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";
import { chatIdFor, ensureChat, findPublicProfile, upsertPublicProfile, watchPresence, startPresence, watchTyping, setTyping, callRef, callIceRef, ref as rtdbRef, set as rtdbSet, update as rtdbUpdate, onValue as rtdbOnValue, push as rtdbPush } from "./realtime";
import { database as rtdb } from "./firebase";
import { arrayUnion } from "firebase/firestore";
import "./styles.css";

const LS = "wa-upgraded-local-v3";
const defaultProfile = {
  name: "RIGHT",
  about: "Hey there! I am using WhatsApp Style.",
  username: "no_name_12345",
  phone: "",
  links: "",
  photo: "",
  friendCode: "",
};

function generateFriendCode() {
  return String(Math.floor(100000 + Math.random() * 900000));
}

function loadLocal() {
  try { return JSON.parse(localStorage.getItem(LS) || "{}"); } catch { return {}; }
}
function saveLocal(value) { localStorage.setItem(LS, JSON.stringify(value)); }

function App() {
  const initial = loadLocal();
  const [user, setUser] = useState(null);
  const [authReady, setAuthReady] = useState(false);
  const [page, setPage] = useState("chats");
  const [menu, setMenu] = useState(false);
  const [local, setLocal] = useState(initial);
  const [profile, setProfile] = useState({ ...defaultProfile, ...(initial.profile || {}) });
  const [lockEnabled, setLockEnabled] = useState(!!initial.lockEnabled);
  const [unlocked, setUnlocked] = useState(!initial.lockEnabled);
  const [toast, setToast] = useState("");
  const [ai, setAi] = useState(initial.ai || []);
  const [aiText, setAiText] = useState("");
  const [aiBusy, setAiBusy] = useState(false);
  const [settings, setSettings] = useState({
    theme: "system", language: "English", reducedMotion: false, highContrast: false, largeText: false,
    notifications: true, messagePreview: true, sounds: true, dataSaver: false, autoDownloadMedia: true,
    readReceipts: true, lastSeen: "Everyone", profilePhotoVisibility: "Everyone", enterToSend: true, mediaVisibility: true,
    ...(initial.settings || {})
  });
  const [cropSrc, setCropSrc] = useState("");
  const [showCrop, setShowCrop] = useState(false);
  const [activeChat, setActiveChat] = useState(null);
  const [incomingCall, setIncomingCall] = useState(null);
  const fileRef = useRef(null);

  useEffect(() => onAuthStateChanged(auth, async (u) => {
    setUser(u); setAuthReady(true);
    if (!u) return;
    try {
      const snap = await getDoc(doc(db, "users", u.uid));
      const saved = snap.exists() ? (snap.data().profile || {}) : {};
      const p = { ...defaultProfile, ...saved, phone: u.phoneNumber || saved.phone || "" };
      if (!p.friendCode) p.friendCode = generateFriendCode();
      setProfile(p); updateLocal({ profile: p });
      await setDoc(doc(db, "users", u.uid), { profile: p, createdAt: serverTimestamp(), updatedAt: serverTimestamp() }, { merge: true });
      await upsertPublicProfile(u.uid, p);
      await startPresence(u.uid);
    } catch (error) { notify(`Firebase sync failed: ${error.message}`); }
  }), []);

  useEffect(() => { if (!user) return; const c = rtdbOnValue(callRef("incoming"), () => {}); return () => c(); }, [user]);
  useEffect(() => { if (toast) { const t = setTimeout(() => setToast(""), 2600); return () => clearTimeout(t); } }, [toast]);
  useEffect(() => setUnlocked(!lockEnabled), [lockEnabled]);

  function updateLocal(extra = {}) { setLocal(current => { const next = { ...current, ...extra }; saveLocal(next); return next; }); }
  function updateSettings(patch) { setSettings(current => { const next = { ...current, ...patch }; updateLocal({ settings: next }); return next; }); }
  function notify(message) { setToast(message); }
  async function saveProfile(nextProfile) {
    setProfile(nextProfile); updateLocal({ profile: nextProfile });
    if (user) {
      await setDoc(doc(db, "users", user.uid), { profile: nextProfile, updatedAt: serverTimestamp() }, { merge: true });
      await upsertPublicProfile(user.uid, nextProfile);
    }
  }
  function setAppLock(enabled) { setLockEnabled(enabled); updateLocal({ lockEnabled: enabled }); setUnlocked(!enabled); }
  async function logout() { try { await signOut(auth); setPage("chats"); notify("Signed out"); } catch (e) { notify(e.message || "Sign out failed"); } }

  if (!authReady) return <Splash text="Starting secure session…" />;
  if (!user) return <LoginScreen />;
  if (lockEnabled && !unlocked) return <BiometricLock onUnlock={() => setUnlocked(true)} onDisable={() => setAppLock(false)} />;

  const me = { uid: user.uid, name: profile.name || "User", photo: profile.photo || "", friendCode: profile.friendCode || "" };
  const appClass = `app theme-${settings.theme || "system"} ${settings.largeText ? "large-text" : ""} ${settings.highContrast ? "high-contrast" : ""} ${settings.reducedMotion ? "reduced-motion" : ""}`;
  return <div className={appClass}>
    <CallManager me={me} />
    {page === "chats" && <Chats me={me} profile={profile} onMeta={() => setPage("meta")} onMenu={() => setMenu(true)} onNotify={notify} onOpenChat={(chat) => { setActiveChat(chat); setPage("chat"); }} />}
    {page === "chat" && activeChat && <ChatScreen me={me} chat={activeChat} onBack={() => { setActiveChat(null); setPage("chats"); }} onNotify={notify} />}
    {page === "updates" && <Updates profile={profile} onNotify={notify} />}
    {page === "communities" && <Communities onNotify={notify} />}
    {page === "calls" && <Calls me={me} onNotify={notify} onOpenChat={(chat) => { setActiveChat(chat); setPage("chat"); }} />}
    {page === "settings" && <Settings profile={profile} onBack={() => setPage("chats")} onProfile={() => setPage("profile")} onPrivacy={() => setPage("privacy")} onChats={() => setPage("chat-settings")} onOpen={(p) => setPage(p)} onNotify={notify} onLogout={logout} />}
    {page === "friends" && <Friends me={me} onBack={() => setPage("settings")} onNotify={notify} onOpenChat={(chat) => { setActiveChat(chat); setPage("chat"); }} />}
    {page === "profile" && <Profile profile={profile} user={user} onBack={() => setPage("settings")} onSave={saveProfile} fileRef={fileRef} cropSrc={cropSrc} setCropSrc={setCropSrc} showCrop={showCrop} setShowCrop={setShowCrop} />}
    {page === "privacy" && <Privacy lockEnabled={lockEnabled} setLock={setAppLock} onBack={() => setPage("settings")} onNotify={notify} settings={settings} updateSettings={updateSettings} />}
    {page === "chat-settings" && <ChatSettings settings={settings} updateSettings={updateSettings} lockEnabled={lockEnabled} setLock={setAppLock} onBack={() => setPage("settings")} onNotify={notify} />}
    {page.startsWith("settings-") && <SettingsDetail type={page.slice(9)} settings={settings} updateSettings={updateSettings} profile={profile} onBack={() => setPage("settings")} onNotify={notify} />}
    {page === "meta" && <MetaAI messages={ai} setMessages={(m) => { setAi(m); updateLocal({ ai: m }); }} text={aiText} setText={setAiText} busy={aiBusy} setBusy={setAiBusy} onBack={() => setPage("chats")} />}
    {menu && <SideMenu close={() => setMenu(false)} setPage={(p) => { setMenu(false); setPage(p); }} notify={notify} />}
    {incomingCall && <IncomingCallBanner call={incomingCall} me={me} onClose={() => setIncomingCall(null)} />}
    {!['settings','profile','privacy','chat-settings','meta','chat'].includes(page) && !page.startsWith('settings-') && <Bottom page={page} setPage={setPage} />}
    {toast && <div className="toast">{toast}</div>}
  </div>;
}

function IncomingCallBanner({ call, me, onClose }) {
  return <div className="incoming-call"><div><b>Incoming {call.kind === "video" ? "video" : "voice"} call</b><small>{call.callerName || "Contact"}</small></div><button className="danger" onClick={onClose}>Decline</button><button className="green" onClick={() => { window.dispatchEvent(new CustomEvent("accept-firebase-call", { detail: call })); onClose(); }}>Accept</button></div>;
}

function Splash({ text }) {
  return <div className="splash"><div className="logo">◉</div><b>WhatsApp Style</b><span>{text}</span></div>;
}

function LoginScreen() {
  const countries = [
    { name: "India", flag: "🇮🇳", code: "+91", digits: 10 },
    { name: "Pakistan", flag: "🇵🇰", code: "+92", digits: 10 },
    { name: "Bangladesh", flag: "🇧🇩", code: "+880", digits: 10 },
    { name: "Nepal", flag: "🇳🇵", code: "+977", digits: 10 },
    { name: "United States", flag: "🇺🇸", code: "+1", digits: 10 },
    { name: "United Kingdom", flag: "🇬🇧", code: "+44", digits: 10 },
    { name: "United Arab Emirates", flag: "🇦🇪", code: "+971", digits: 9 },
    { name: "Australia", flag: "🇦🇺", code: "+61", digits: 9 },
  ];

  const [country, setCountry] = useState(countries[0]);
  const [phone, setPhone] = useState("");
  const [code, setCode] = useState("");
  const [captcha, setCaptcha] = useState("");
  const [captchaText, setCaptchaText] = useState(() => makeCaptcha());
  const [otpCode, setOtpCode] = useState("");
  const [sent, setSent] = useState(false);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  function makeCaptcha() {
    return String(Math.floor(1000 + Math.random() * 9000));
  }

  function refreshCaptcha() {
    setCaptcha("");
    setCaptchaText(makeCaptcha());
  }

  function cleanDigits(value) {
    return value.replace(/\D/g, "");
  }

  function validatePhone() {
    const digits = cleanDigits(phone);
    return digits.length === country.digits;
  }

  async function send() {
    setErr("");
    const digits = cleanDigits(phone);

    if (digits.length !== country.digits) {
      setErr(`Enter a valid ${country.digits}-digit mobile number.`);
      return;
    }

    if (cleanDigits(captcha) !== captchaText) {
      setErr("CAPTCHA is incorrect. Enter the code shown above.");
      refreshCaptcha();
      return;
    }

    setBusy(true);
    try {
      // Generate a fresh 6-digit code every time the user requests a login code.
      // Demo mode: the code is displayed on screen instead of being sent by SMS.
      const freshCode = String(Math.floor(100000 + Math.random() * 900000));
      setOtpCode(freshCode);
      setSent(true);
      setCode("");
      setErr("");
    } finally {
      setBusy(false);
    }
  }

  async function verify() {
    setErr("");

    if (!otpCode || code !== otpCode) {
      setErr("Wrong verification code. Use the new 6-digit code shown above.");
      return;
    }

    setBusy(true);
    try {
      // Create a Firebase session so the existing app/database/profile system
      // continues to work without requiring an SMS OTP.
      await signInAnonymously(auth);
    } catch (e) {
      setErr(friendlyFirebaseError(e));
    } finally {
      setBusy(false);
    }
  }

  const fullPhone = `${country.code}${cleanDigits(phone)}`;

  return (
    <div className="auth">
      <div className="auth-card login-modern">
        <div className="login-logo">◉</div>
        <div className="brand">WhatsApp Style</div>

        {!sent ? (
          <>
            <h1>Login to continue</h1>
            <p>Select your region, enter your mobile number, complete CAPTCHA, then continue.</p>

            <label>Country / Region</label>
            <select
              className="country-select"
              value={country.code}
              onChange={(e) => {
                const next = countries.find((c) => c.code === e.target.value) || countries[0];
                setCountry(next);
                setPhone("");
                setErr("");
              }}
            >
              {countries.map((c) => (
                <option key={`${c.name}-${c.code}`} value={c.code}>
                  {c.flag} {c.name} ({c.code})
                </option>
              ))}
            </select>

            <label>Mobile number</label>
            <div className="phone-row">
              <div className="dial-code">{country.code}</div>
              <input
                value={phone}
                onChange={(e) => setPhone(cleanDigits(e.target.value).slice(0, country.digits))}
                placeholder={country.digits === 10 ? "9876543210" : "Mobile number"}
                inputMode="numeric"
                autoComplete="tel"
              />
            </div>

            <div className="captcha-card">
              <div>
                <small>CAPTCHA</small>
                <strong>{captchaText}</strong>
              </div>
              <button type="button" className="captcha-refresh" onClick={refreshCaptcha} aria-label="Refresh CAPTCHA">↻</button>
            </div>

            <label>Enter CAPTCHA</label>
            <input
              value={captcha}
              onChange={(e) => setCaptcha(cleanDigits(e.target.value).slice(0, 4))}
              placeholder="Enter 4-digit CAPTCHA"
              inputMode="numeric"
            />

            <button
              className="green"
              disabled={busy || !validatePhone() || captcha.length !== 4}
              onClick={send}
            >
              {busy ? "Please wait…" : "Continue"}
            </button>
          </>
        ) : (
          <>
            <div className="code-banner">
              <span>YOUR 6-DIGIT LOGIN CODE</span>
              <strong>{otpCode}</strong>
            </div>

            <h1>Enter verification code</h1>
            <p>New code for <b>{fullPhone}</b></p>

            <label>6-digit code</label>
            <input
              className="otp-input"
              value={code}
              onChange={(e) => setCode(cleanDigits(e.target.value).slice(0, 6))}
              placeholder="123456"
              inputMode="numeric"
              autoComplete="one-time-code"
              maxLength={6}
            />

            <button
              className="green"
              disabled={busy || code.length !== 6}
              onClick={verify}
            >
              {busy ? "Opening app…" : "Verify & Open App"}
            </button>

            <button
              className="textbtn"
              onClick={() => {
                setSent(false);
                setCode("");
                setOtpCode("");
                setErr("");
                refreshCaptcha();
              }}
            >
              ← Change number
            </button>
          </>
        )}

        {err && <div className="error">{err}</div>}
        <p className="tiny login-note">
          Demo login mode: a new 6-digit code is generated each time you request login. It is shown on screen and is not sent by SMS.
          For production security, use Firebase Phone Authentication with real SMS OTP.
        </p>
      </div>
    </div>
  );
}

function friendlyFirebaseError(error) {
  const code = error?.code || "";
  const map = {
    "auth/invalid-phone-number": "Invalid phone number. Use international format like +919876543210.",
    "auth/too-many-requests": "Too many attempts. Please wait and try again later.",
    "auth/quota-exceeded": "SMS quota exceeded for this Firebase project.",
    "auth/invalid-verification-code": "That verification code is incorrect.",
    "auth/code-expired": "That code expired. Request a new code.",
    "auth/operation-not-allowed": "The required Firebase sign-in provider is not enabled. Enable Anonymous Authentication in Firebase Console.",
    "auth/admin-restricted-operation": "Anonymous sign-in is disabled. Enable Anonymous Authentication in Firebase Console.",
    "auth/unauthorized-domain": "This domain is not authorized in Firebase Authentication.",
  };
  return map[code] || error?.message || "Firebase authentication failed.";
}

async function registerWebAuthn() {
  if (!window.PublicKeyCredential || !window.isSecureContext) throw new Error("Biometric unlock needs HTTPS (or localhost) and a WebAuthn-capable browser.");
  const challenge = crypto.getRandomValues(new Uint8Array(32));
  const credential = await navigator.credentials.create({ publicKey: {
    challenge,
    rp: { name: "WhatsApp Style App", id: location.hostname },
    user: { id: crypto.getRandomValues(new Uint8Array(16)), name: `device-${Date.now()}`, displayName: "Device user" },
    pubKeyCredParams: [{ alg: -7, type: "public-key" }, { alg: -257, type: "public-key" }],
    authenticatorSelection: { authenticatorAttachment: "platform", userVerification: "required" },
    timeout: 60000,
  }});
  localStorage.setItem("waWebAuthn", JSON.stringify({ id: credential.id, created: Date.now() }));
}

async function useWebAuthn() {
  if (!window.PublicKeyCredential || !window.isSecureContext) throw new Error("WebAuthn is unavailable in this context.");
  const raw = localStorage.getItem("waWebAuthn");
  if (!raw) throw new Error("No biometric credential enrolled.");
  const stored = JSON.parse(raw);
  const challenge = crypto.getRandomValues(new Uint8Array(32));
  await navigator.credentials.get({ publicKey: {
    challenge,
    rpId: location.hostname,
    allowCredentials: [{ id: base64urlToBytes(stored.id), type: "public-key" }],
    userVerification: "required",
    timeout: 60000,
  }});
}
function base64urlToBytes(value) {
  const padded = value + "=".repeat((4 - value.length % 4) % 4);
  const decoded = atob(padded.replace(/-/g, "+").replace(/_/g, "/"));
  return Uint8Array.from(decoded, (c) => c.charCodeAt(0));
}

function BiometricLock({ onUnlock, onDisable }) {
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState("Use fingerprint, face unlock, or your device PIN/security key.");
  const [has, setHas] = useState(!!localStorage.getItem("waWebAuthn"));
  async function unlock() {
    setBusy(true);
    try { await useWebAuthn(); onUnlock(); } catch (e) { setMsg(e.message || "Unlock failed"); }
    finally { setBusy(false); }
  }
  async function enroll() {
    setBusy(true);
    try { await registerWebAuthn(); setHas(true); setMsg("Device credential enrolled. Tap Unlock."); }
    catch (e) { setMsg(e.message || "Enrollment failed"); }
    finally { setBusy(false); }
  }
  return <div className="lock"><div className="lock-card"><div className="lock-icon">🔒</div><h1>App locked</h1><p>{msg}</p>{!has ? <button className="green" disabled={busy} onClick={enroll}>{busy ? "Waiting…" : "Set up biometric / device lock"}</button> : <button className="green" disabled={busy} onClick={unlock}>{busy ? "Checking…" : "Unlock with biometrics"}</button>}<button className="textbtn" onClick={onDisable}>Disable app lock</button></div></div>;
}

function Chats({ me, profile, onMeta, onMenu, onNotify, onOpenChat }) {
  const [chats, setChats] = useState([]);
  const [showNew, setShowNew] = useState(false);
  const [target, setTarget] = useState("");
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    const q = query(collection(db, "chats"), where("participants", "array-contains", me.uid), limit(100));
    return onSnapshot(q, snap => {
      const rows = snap.docs.map(d => ({ id: d.id, ...d.data() })).sort((a,b) => (b.updatedAt?.seconds || 0) - (a.updatedAt?.seconds || 0));
      setChats(rows);
    }, e => onNotify(`Chat sync error: ${e.message}`));
  }, [me.uid]);
  async function createChat() {
    const value = target.trim();
    if (!value || value === me.uid) return;
    setBusy(true);
    try {
      const other = await findPublicProfile(value);
      if (!other) throw new Error("User not found. Enter the other user's Firebase UID.");
      const otherUser = { uid: other.uid, name: other.name, photo: other.photo };
      const chatId = chatIdFor(me.uid, other.uid);
      await ensureChat(chatId, me, otherUser);
      setShowNew(false); setTarget(""); onOpenChat({ id: chatId, other: otherUser });
    } catch (e) { onNotify(e.message); } finally { setBusy(false); }
  }
  return <section className="screen">
    <header><h1>Chats</h1><div className="head-actions"><button onClick={() => setShowNew(true)}>✎</button><button onClick={onMenu}>⋮</button></div></header>
    <div className="search" onClick={onMeta}>⌕ <input readOnly placeholder="Ask Meta AI or Search" /></div>
    <div className="pills"><span className="active">All</span><span>Favourites</span><span>Groups</span><span onClick={() => setShowNew(true)}>＋</span></div>
    <button className="chat-row" onClick={onMeta}><div className="ai-avatar">✦</div><div><b>Meta AI ✓</b><small>Ask Meta AI anything…</small></div><time>Now</time></button>
    {chats.length === 0 && <div className="empty">No real-time chats yet.<br /><small>Tap ✎ and enter another user's Firebase UID.</small></div>}
    {chats.map(chat => {
      const otherUid = chat.participants?.find(x => x !== me.uid);
      const other = chat.participantProfiles?.[otherUid] || { name: "Contact", photo: "" };
      return <button className="chat-row" key={chat.id} onClick={() => onOpenChat({ id: chat.id, other: { uid: otherUid, ...other } })}>
        <div className="avatar">{other.photo ? <img src={other.photo} /> : (other.name || "U").slice(0,1)}</div>
        <div><b>{other.name || "Contact"}</b><small>{chat.lastMessage || "No messages yet"}</small></div>
        <time>{formatTime(chat.updatedAt)}</time>
      </button>;
    })}
    {showNew && <div className="dialog-overlay"><div className="dialog"><h2>New chat</h2><p>Enter the other user's Firebase UID.</p><input autoFocus value={target} onChange={e => setTarget(e.target.value)} placeholder="e.g. 8Xy...uid" /><div className="dialog-actions"><button onClick={() => setShowNew(false)}>Cancel</button><button className="green" disabled={busy} onClick={createChat}>{busy ? "Opening…" : "Open chat"}</button></div></div></div>}
  </section>;
}

function formatTime(ts) {
  if (!ts) return "";
  const d = ts.toDate ? ts.toDate() : new Date(ts);
  return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

function ChatScreen({ me, chat, onBack, onNotify }) {
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState("");
  const [otherOnline, setOtherOnline] = useState(false);
  const [typing, setTypingState] = useState(false);
  const [sending, setSending] = useState(false);
  const [plusOpen, setPlusOpen] = useState(false);
  const [chatMenu, setChatMenu] = useState(false);
  const [recording, setRecording] = useState(false);
  const [replyTo, setReplyTo] = useState(null);
  const [pinnedId, setPinnedId] = useState("");
  const [contactOpen, setContactOpen] = useState(false);
  const [contactList, setContactList] = useState([]);
  const [eventOpen, setEventOpen] = useState(false);
  const typingTimer = useRef(null);
  const bottomRef = useRef(null);
  const fileRef = useRef(null);
  const cameraRef = useRef(null);
  const mediaRecorderRef = useRef(null);
  const chunksRef = useRef([]);
  const other = chat.other;

  useEffect(() => {
    const q = query(collection(db, `chats/${chat.id}/messages`), orderBy("createdAt", "asc"), limit(500));
    return onSnapshot(q, async snap => {
      const rows = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      setMessages(rows);
      const pin = rows.find(m => m.pinned);
      setPinnedId(pin?.id || "");
      const incoming = rows.filter(m => m.senderId !== me.uid && !(m.deliveredBy || []).includes(me.uid));
      if (incoming.length) {
        const batch = writeBatch(db);
        incoming.forEach(m => batch.update(doc(db, `chats/${chat.id}/messages`, m.id), { deliveredBy: arrayUnion(me.uid) }));
        try { await batch.commit(); } catch {}
      }
      const unread = rows.filter(m => m.senderId !== me.uid && !(m.readBy || []).includes(me.uid));
      if (unread.length) {
        const batch = writeBatch(db);
        unread.forEach(m => batch.update(doc(db, `chats/${chat.id}/messages`, m.id), { readBy: arrayUnion(me.uid), readAt: serverTimestamp(), deliveredBy: arrayUnion(me.uid) }));
        try { await batch.commit(); } catch {}
      }
      setTimeout(() => bottomRef.current?.scrollIntoView({ behavior: "smooth" }), 0);
    }, e => onNotify(`Message sync error: ${e.message}`));
  }, [chat.id, me.uid]);
  useEffect(() => watchPresence(other.uid, setOtherOnline), [other.uid]);
  useEffect(() => watchTyping(chat.id, other.uid, setTypingState), [chat.id, other.uid]);
  useEffect(() => () => { if (typingTimer.current) clearTimeout(typingTimer.current); setTyping(chat.id, me.uid, false).catch(() => {}); }, [chat.id, me.uid]);

  async function sendMessage(payload, preview) {
    if (sending) return;
    setSending(true);
    try {
      const now = serverTimestamp();
      await addDoc(collection(db, `chats/${chat.id}/messages`), { senderId: me.uid, createdAt: now, readBy: [me.uid], deliveredBy: [me.uid], ...payload });
      await updateDoc(doc(db, "chats", chat.id), { lastMessage: preview, lastSenderId: me.uid, updatedAt: now });
      setText(""); setReplyTo(null); await setTyping(chat.id, me.uid, false);
      setTimeout(() => bottomRef.current?.scrollIntoView({ behavior: "smooth" }), 20);
    } catch (e) { onNotify(`Send failed: ${e.message}`); } finally { setSending(false); }
  }
  async function send() {
    const body = text.trim(); if (!body) return;
    await sendMessage({ text: body, type: "text", replyTo: replyTo ? { id: replyTo.id, text: replyTo.text || replyTo.fileName || "Media" } : null }, body.slice(0, 80));
  }
  function input(v) {
    setText(v);
    setTyping(chat.id, me.uid, !!v.trim()).catch(() => {});
    if (typingTimer.current) clearTimeout(typingTimer.current);
    if (v.trim()) typingTimer.current = setTimeout(() => setTyping(chat.id, me.uid, false).catch(() => {}), 1800);
  }
  async function uploadMedia(file) {
    if (!file) return;
    if (file.size > 25 * 1024 * 1024) { onNotify("File must be 25 MB or smaller"); return; }
    try {
      setSending(true);
      const safe = file.name.replace(/[^a-zA-Z0-9._-]/g, "_");
      const storageRef = ref(storage, `chats/${chat.id}/${me.uid}/${Date.now()}_${safe}`);
      const snap = await uploadBytes(storageRef, file, { contentType: file.type || "application/octet-stream" });
      const url = await getDownloadURL(snap.ref);
      const type = file.type.startsWith("image/") ? "image" : file.type.startsWith("video/") ? "video" : file.type.startsWith("audio/") ? "audio" : "file";
      const now = serverTimestamp();
      const preview = type === "image" ? "📷 Photo" : type === "video" ? "🎥 Video" : type === "audio" ? "🎤 Voice message" : `📎 ${file.name}`;
      await addDoc(collection(db, `chats/${chat.id}/messages`), { senderId: me.uid, createdAt: now, readBy: [me.uid], deliveredBy: [me.uid], type, url, fileName: file.name, mimeType: file.type, size: file.size, replyTo: replyTo ? { id: replyTo.id, text: replyTo.text || replyTo.fileName || "Media" } : null });
      await updateDoc(doc(db, "chats", chat.id), { lastMessage: preview, lastSenderId: me.uid, updatedAt: now });
      setReplyTo(null); onNotify("Sent");
    } catch (e) { onNotify(`Upload failed: ${e.message}`); }
    finally { setSending(false); setPlusOpen(false); }
  }
  function pick(kind) {
    const input = kind === "camera" ? cameraRef.current : fileRef.current;
    if (!input) return;
    input.accept = kind === "photo" || kind === "camera" ? "image/*" : kind === "video" ? "video/*" : kind === "audio" ? "audio/*" : "*/*";
    if (kind === "camera") input.setAttribute("capture", "environment"); else input.removeAttribute("capture");
    input.click();
  }
  async function sendLocation() {
    setPlusOpen(false);
    if (!navigator.geolocation) return onNotify("Location is not supported");
    navigator.geolocation.getCurrentPosition(async pos => {
      const { latitude, longitude } = pos.coords;
      await sendMessage({ type:"location", latitude, longitude, text:"Live location" }, "📍 Location");
    }, err => onNotify(err.message || "Location permission denied"), { enableHighAccuracy:true, timeout:10000 });
  }
  async function sendPayment() {
    setPlusOpen(false);
    const upi = window.prompt("Enter UPI ID"); if (!upi) return;
    const amount = window.prompt("Amount in ₹ (optional)") || "";
    const link = `upi://pay?pa=${encodeURIComponent(upi)}&pn=${encodeURIComponent(other.name||"Contact")}&am=${encodeURIComponent(amount)}&cu=INR`;
    await sendMessage({type:"payment", upi, amount, url:link, text:`Payment${amount?` ₹${amount}`:""}`}, `💳 Payment${amount?` ₹${amount}`:""}`);
    try { window.location.href = link; } catch {}
  }
  async function createEventMessage() {
    setEventOpen(false); setPlusOpen(false);
    const title = window.prompt("Event name"); if (!title) return;
    const when = window.prompt("Date and time, e.g. 28 Sep 2026 7:00 PM"); if (!when) return;
    await sendMessage({type:"event", eventTitle:title, eventWhen:when, text:title}, `📅 ${title}`);
  }
  async function openContacts() {
    setPlusOpen(false);
    try {
      const q = query(collection(db,"friendships"),where("participants","array-contains",me.uid));
      const snap = await getDocs(q);
      const rows = await Promise.all(snap.docs.filter(d=>d.data().status==="accepted").map(async d=>{const uid=d.data().participants.find(x=>x!==me.uid);const ps=await getDoc(doc(db,"publicProfiles",uid));return {uid,...(ps.exists()?ps.data():{name:"User",photo:""})};}));
      setContactList(rows); setContactOpen(true);
    } catch(e){onNotify(e.message||"Could not load contacts");}
  }
  async function sendContact(c) {
    setContactOpen(false);
    await sendMessage({type:"contact",contactUid:c.uid,contactName:c.name||"User",contactPhoto:c.photo||"",text:c.name||"Contact"}, `👤 ${c.name||"Contact"}`);
  }

  async function startRecording() {
    if (recording) { mediaRecorderRef.current?.stop(); return; }
    if (!navigator.mediaDevices?.getUserMedia || !window.MediaRecorder) { onNotify("Voice recording is not supported in this browser"); return; }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream); chunksRef.current = [];
      recorder.ondataavailable = e => e.data.size && chunksRef.current.push(e.data);
      recorder.onstop = async () => {
        stream.getTracks().forEach(t => t.stop());
        setRecording(false);
        const blob = new Blob(chunksRef.current, { type: recorder.mimeType || "audio/webm" });
        await uploadMedia(new File([blob], `voice-${Date.now()}.webm`, { type: blob.type }));
      };
      recorder.onerror = () => setRecording(false);
      mediaRecorderRef.current = recorder; recorder.start(); setRecording(true); onNotify("Recording… tap mic again to send");
    } catch (e) { onNotify(e.message || "Microphone permission denied"); }
  }
  async function clearChat() {
    setChatMenu(false);
    if (!window.confirm("Clear this chat for both users?")) return;
    try {
      for (let i = 0; i < messages.length; i += 400) {
        const batch = writeBatch(db);
        messages.slice(i, i + 400).forEach(m => batch.delete(doc(db, `chats/${chat.id}/messages`, m.id)));
        await batch.commit();
      }
      await updateDoc(doc(db, "chats", chat.id), { lastMessage: "", updatedAt: serverTimestamp() });
      onNotify("Chat cleared");
    } catch (e) { onNotify(`Could not clear chat: ${e.message}`); }
  }
  async function pinMessage(m) {
    try {
      const batch = writeBatch(db);
      messages.filter(x => x.pinned && x.id !== m.id).forEach(x => batch.update(doc(db, `chats/${chat.id}/messages`, x.id), { pinned: false }));
      batch.update(doc(db, `chats/${chat.id}/messages`, m.id), { pinned: !m.pinned });
      await batch.commit(); onNotify(m.pinned ? "Unpinned" : "Pinned");
    } catch (e) { onNotify(e.message); }
  }
  async function deleteMessage(m) {
    if (m.senderId !== me.uid) return onNotify("You can delete only your own messages");
    try { await deleteDoc(doc(db, `chats/${chat.id}/messages`, m.id)); onNotify("Message deleted"); } catch (e) { onNotify(e.message); }
  }
  async function copyMessage(m) {
    try { await navigator.clipboard.writeText(m.text || m.fileName || "Media"); onNotify("Copied"); } catch { onNotify("Copy is not available"); }
  }
  function startCall(kind) { window.dispatchEvent(new CustomEvent("start-firebase-call", { detail: { other, kind, me } })); }
  return <section className="screen chat-screen">
    <div className="chat-header">
      <button onClick={onBack}>‹</button><div className="avatar small">{other.photo ? <img src={other.photo} /> : (other.name || "U").slice(0,1)}</div>
      <div className="chat-title"><b>{other.name || "Contact"}</b><small>{typing ? "typing…" : otherOnline ? "online" : "offline"}</small></div>
      <button title="Voice call" onClick={() => startCall("audio")}>☎</button><button title="Video call" onClick={() => startCall("video")}>▣</button>
      <button title="Chat menu" onClick={() => setChatMenu(v => !v)}>⋮</button>
      {chatMenu && <div className="chat-menu"><button onClick={() => { setChatMenu(false); setPlusOpen(false); onNotify("Use the chat search field to find messages"); }}>Search</button><button onClick={() => { setChatMenu(false); setPlusOpen(false); }}>Mute</button><button onClick={clearChat}>Clear chat</button></div>}
    </div>
    {pinnedId && <button className="pinned-bar" onClick={() => document.getElementById(`msg-${pinnedId}`)?.scrollIntoView({behavior:"smooth"})}>📌 Pinned message</button>}
    <div className="messages">{messages.map(m => <MessageBubble key={m.id} message={m} mine={m.senderId === me.uid} onPin={pinMessage} onDelete={deleteMessage} onCopy={copyMessage} onReply={setReplyTo} />)}{typing && <div className="typing-bubble">typing…</div>}<div ref={bottomRef} /></div>
    {replyTo && <div className="reply-preview"><span><b>Replying to message</b><small>{replyTo.text || replyTo.fileName || "Media"}</small></span><button onClick={() => setReplyTo(null)}>×</button></div>}
    <input ref={fileRef} hidden type="file" onChange={e => { const f=e.target.files?.[0]; e.target.value=""; uploadMedia(f); }} />
    <input ref={cameraRef} hidden type="file" accept="image/*" capture="environment" onChange={e => { const f=e.target.files?.[0]; e.target.value=""; uploadMedia(f); }} />
    {plusOpen && <div className="plus-menu">
      <button onClick={() => pick("camera")}>📷 Camera</button><button onClick={() => pick("photo")}>🖼️ Gallery</button><button onClick={() => pick("video")}>🎥 Video</button><button onClick={() => pick("file")}>📎 Document</button><button onClick={() => pick("audio")}>🎵 Audio</button><button onClick={sendLocation}>📍 Location</button><button onClick={openContacts}>👤 Contact</button><button onClick={sendPayment}>💳 Payment</button><button onClick={createEventMessage}>📅 Event</button><button onClick={() => pick("photo")}>✨ AI images</button>
    </div>}
    {contactOpen && <div className="dialog-overlay" onClick={() => setContactOpen(false)}><div className="dialog contact-dialog" onClick={e=>e.stopPropagation()}><h2>Contact</h2>{contactList.length?contactList.map(c=><button className="contact-pick" key={c.uid} onClick={()=>sendContact(c)}><div className="avatar">{c.photo?<img src={c.photo}/>:String(c.name||"U").slice(0,1)}</div><b>{c.name||"User"}</b></button>):<div className="empty">No friends yet.</div>}<button onClick={()=>setContactOpen(false)}>Cancel</button></div></div>}
    <div className="composer"><button className="plus-btn" onClick={() => setPlusOpen(v => !v)}>＋</button><input value={text} onChange={e => input(e.target.value)} onKeyDown={e => e.key === "Enter" && send()} placeholder="Message" /><button title="Voice message" className={`mic-btn ${recording ? "recording" : ""}`} onClick={startRecording}>🎙</button><button className="send-btn" onClick={send} disabled={sending || !text.trim()}>➤</button></div>
  </section>;
}

function MessageBubble({ message, mine, onPin, onDelete, onCopy, onReply }) {
  const read = mine && (message.readBy || []).length > 1;
  const delivered = mine && (message.deliveredBy || []).length > 1;
  const [menu, setMenu] = useState(false);
  let ticks = ""; let tickClass = "";
  if (mine) { ticks = read ? "✓✓" : delivered ? "✓✓" : "✓"; tickClass = read ? "read" : ""; }
  return <div id={`msg-${message.id}`} className={`message-line ${mine ? "mine" : "theirs"}`}><div className="message-bubble">
    {message.replyTo && <div className="quoted-message">↩ {message.replyTo.text || message.replyTo.fileName || "Media"}</div>}
    {message.type === "image" && <img className="message-media" src={message.url} alt={message.fileName || "Photo"} loading="lazy" />}
    {message.type === "video" && <video className="message-media" src={message.url} controls playsInline preload="metadata" />}
    {message.type === "audio" && <audio className="message-audio" src={message.url} controls preload="metadata" />}
    {message.type === "file" && <a className="file-message" href={message.url} target="_blank" rel="noreferrer">📎 {message.fileName || "Document"}</a>}
    {message.type === "location" && <a className="location-card" href={`https://www.google.com/maps?q=${message.latitude},${message.longitude}`} target="_blank" rel="noreferrer">📍 <b>Location</b><small>Open in Maps</small></a>}
    {message.type === "payment" && <a className="payment-card" href={message.url || "#"}>💳 <b>Payment{message.amount?` ₹${message.amount}`:""}</b><small>{message.upi}</small></a>}
    {message.type === "event" && <div className="event-card">📅 <b>{message.eventTitle}</b><small>{message.eventWhen}</small></div>}
    {message.type === "contact" && <div className="contact-card"><div className="avatar small">{message.contactPhoto?<img src={message.contactPhoto}/>:String(message.contactName||"U").slice(0,1)}</div><b>{message.contactName||"Contact"}</b></div>}
    {message.type === "text" && <div>{message.text}</div>}
    {message.pinned && <small className="pin-label">📌 Pinned</small>}
    <span>{formatTime(message.createdAt)} {mine && <b className={tickClass}>{ticks}</b>} <button className="msg-more" onClick={() => setMenu(v=>!v)}>⋮</button></span>
    {menu && <div className="message-actions"><button onClick={() => { setMenu(false); onReply(message); }}>Reply</button><button onClick={() => { setMenu(false); onCopy(message); }}>Copy</button><button onClick={() => { setMenu(false); onPin(message); }}>{message.pinned ? "Unpin" : "Pin"}</button>{mine && <button onClick={() => { setMenu(false); onDelete(message); }}>Delete</button>}</div>}
  </div></div>;
}

function Calls({ me, onNotify }) {
  const [history, setHistory] = useState([]);
  useEffect(() => {
    const q = query(collection(db, "callLogs"), where("participants", "array-contains", me.uid), limit(50));
    return onSnapshot(q, snap => setHistory(snap.docs.map(d => ({ id: d.id, ...d.data() })).sort((a,b) => (b.createdAt?.seconds || 0) - (a.createdAt?.seconds || 0))), () => {});
  }, [me.uid]);
  return <section className="screen"><header><h1>Calls</h1><div className="head-actions"><button onClick={() => onNotify("Use a chat to start a call")}>⌕</button><button onClick={() => onNotify("Call settings")}>⋮</button></div></header><div className="call-tools"><button onClick={() => onNotify("Open a chat and tap ☎")}>☎<small>Call</small></button><button onClick={() => onNotify("Schedule calls can be added with Calendar integration")}>▣<small>Schedule</small></button><button onClick={() => onNotify("Keypad opened")}>⠿<small>Keypad</small></button><button onClick={() => onNotify("Favourites opened")}>♡<small>Favourites</small></button></div><h2>Recent</h2>{history.length === 0 ? <div className="empty">No recent calls.</div> : history.map(c => <div className="call-row" key={c.id}><div className="avatar">{(c.otherName || "U").slice(0,1)}</div><div><b>{c.otherName || "Contact"}</b><small>{c.kind === "video" ? "Video" : "Voice"} · {c.status || "ended"}</small></div><time>{formatTime(c.createdAt)}</time></div>)}</section>;
}

function CallManager({ me }) {
  const [call, setCall] = useState(null);
  const [pending, setPending] = useState(null);
  const pcRef = useRef(null);
  const localStreamRef = useRef(null);
  const remoteStreamRef = useRef(null);
  const localVideo = useRef(null);
  const remoteVideo = useRef(null);
  const pendingIce = useRef([]);
  const callStateRef = useRef(null);
  useEffect(() => { callStateRef.current = call; }, [call]);

  useEffect(() => {
    const incomingRef = rtdbRef(rtdb, `incomingCalls/${me.uid}`);
    const unsub = rtdbOnValue(incomingRef, snap => {
      const val = snap.val() || {};
      const first = Object.entries(val).map(([id, v]) => ({ id, ...v })).find(x => x.status === "ringing");
      if (first && !callStateRef.current) setPending(first);
    });
    const start = e => startOutgoing(e.detail).catch(err => alert(err.message));
    const accept = e => { if (e.detail) acceptIncoming(e.detail).catch(err => alert(err.message)); };
    window.addEventListener("start-firebase-call", start);
    window.addEventListener("accept-firebase-call", accept);
    return () => { unsub(); window.removeEventListener("start-firebase-call", start); window.removeEventListener("accept-firebase-call", accept); cleanup(); };
  }, [me.uid]);

  useEffect(() => { if (call?.remoteStream && remoteVideo.current) remoteVideo.current.srcObject = call.remoteStream; if (call?.localStream && localVideo.current) localVideo.current.srcObject = call.localStream; }, [call]);

  async function createPeer(kind, callId, side) {
    const iceServers = [{ urls: "stun:stun.l.google.com:19302" }];
    if (import.meta.env.VITE_TURN_URL) iceServers.push({ urls: import.meta.env.VITE_TURN_URL, username: import.meta.env.VITE_TURN_USERNAME, credential: import.meta.env.VITE_TURN_CREDENTIAL });
    const pc = new RTCPeerConnection({ iceServers });
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: kind === "video" });
    stream.getTracks().forEach(track => pc.addTrack(track, stream));
    const remote = new MediaStream();
    pc.ontrack = e => { e.streams[0]?.getTracks().forEach(t => remote.addTrack(t)); setCall(c => c ? { ...c, remoteStream: remote } : c); };
    pc.onicecandidate = e => { if (e.candidate) rtdbSet(rtdbPush(callIceRef(callId, side)), e.candidate.toJSON()); };
    pcRef.current = pc; localStreamRef.current = stream; remoteStreamRef.current = remote;
    return pc;
  }
  function listenIce(callId, side) {
    return rtdbOnValue(callIceRef(callId, side), async snap => {
      const values = snap.val() || {};
      for (const c of Object.values(values)) {
        try { await pcRef.current?.addIceCandidate(new RTCIceCandidate(c)); } catch {}
      }
    });
  }
  async function startOutgoing({ other, kind }) {
    if (callStateRef.current) return;
    const callId = `${me.uid}_${other.uid}_${Date.now()}`;
    const pc = await createPeer(kind, callId, "caller");
    const offer = await pc.createOffer(); await pc.setLocalDescription(offer);
    const data = { callerId: me.uid, calleeId: other.uid, callerName: me.name, calleeName: other.name, kind, status: "ringing", offer: { type: offer.type, sdp: offer.sdp }, createdAt: Date.now() };
    await rtdbSet(callRef(callId), data);
    await rtdbSet(rtdbRef(rtdb, `incomingCalls/${other.uid}/${callId}`), data);
    const answerUnsub = rtdbOnValue(callRef(callId), async snap => { const v = snap.val(); if (v?.answer && pc.signalingState !== "stable") { try { await pc.setRemoteDescription(new RTCSessionDescription(v.answer)); } catch {} } if (v?.status === "ended") cleanup(); });
    const iceUnsub = listenIce(callId, "callee");
    pc._unsubs = [answerUnsub, iceUnsub];
    setCall({ id: callId, kind, other, localStream: localStreamRef.current, remoteStream: remoteStreamRef.current, direction: "outgoing", status: "ringing" });
  }
  async function acceptIncoming(incoming) {
    setPending(null);
    const callId = incoming.id;
    const pc = await createPeer(incoming.kind, callId, "callee");
    await pc.setRemoteDescription(new RTCSessionDescription(incoming.offer));
    const answer = await pc.createAnswer(); await pc.setLocalDescription(answer);
    await rtdbUpdate(callRef(callId), { answer: { type: answer.type, sdp: answer.sdp }, status: "active" });
    await rtdbSet(rtdbRef(rtdb, `incomingCalls/${me.uid}/${callId}`), { ...incoming, status: "active" });
    const iceUnsub = listenIce(callId, "caller");
    const statusUnsub = rtdbOnValue(callRef(callId), snap => { if (snap.val()?.status === "ended") cleanup(); });
    pc._unsubs = [iceUnsub, statusUnsub];
    const other = { uid: incoming.callerId, name: incoming.callerName || "Contact", photo: "" };
    setCall({ id: callId, kind: incoming.kind, other, localStream: localStreamRef.current, remoteStream: remoteStreamRef.current, direction: "incoming", status: "active" });
  }
  async function hangup() {
    if (!call) return;
    try {
      await rtdbUpdate(callRef(call.id), { status: "ended", endedAt: Date.now() });
      await rtdbSet(rtdbRef(rtdb, `incomingCalls/${call.other.uid}/${call.id}`), null);
      await addDoc(collection(db, "callLogs"), { participants: [me.uid, call.other.uid], otherName: call.other.name || "Contact", kind: call.kind, status: "ended", createdAt: serverTimestamp() });
    } catch {}
    cleanup();
  }
  function cleanup() {
    pcRef.current?._unsubs?.forEach(fn => fn && fn());
    pcRef.current?.close(); pcRef.current = null;
    localStreamRef.current?.getTracks().forEach(t => t.stop()); localStreamRef.current = null;
    remoteStreamRef.current = null; setCall(null); setPending(null);
  }
  return <>{pending && <div className="incoming-call"><div><b>Incoming {pending.kind === "video" ? "video" : "voice"} call</b><small>{pending.callerName}</small></div><button className="danger" onClick={async () => { await rtdbSet(rtdbRef(rtdb, `incomingCalls/${me.uid}/${pending.id}`), null); setPending(null); }}>Decline</button><button className="green" onClick={() => acceptIncoming(pending)}>Accept</button></div>}{call && <div className="call-modal"><div className="call-top"><div><b>{call.kind === "video" ? "Video call" : "Voice call"}</b><small>{call.other.name}</small></div><span>{call.status}</span></div><div className="call-stage">{call.kind === "video" && <><video ref={remoteVideo} autoPlay playsInline className="remote-video" /><video ref={localVideo} autoPlay muted playsInline className="local-video" /></>}{call.kind !== "video" && <div className="voice-avatar">{(call.other.name || "U").slice(0,1)}</div>}</div><div className="call-controls"><button onClick={() => localStreamRef.current?.getAudioTracks().forEach(t => t.enabled = !t.enabled)}>🎙</button>{call.kind === "video" && <button onClick={() => localStreamRef.current?.getVideoTracks().forEach(t => t.enabled = !t.enabled)}>▣</button>}<button className="hangup" onClick={hangup}>☎</button></div></div>}</>;
}

function Updates({ profile, onNotify }) {
  const [statuses, setStatuses] = useState([]);
  const [viewer, setViewer] = useState(null);
  const [text, setText] = useState("");
  const [file, setFile] = useState(null);
  const [publishing, setPublishing] = useState(false);
  const currentUid = auth.currentUser?.uid || "";

  useEffect(() => {
    const q = query(collection(db, "statuses"), orderBy("createdAt", "desc"), limit(100));
    return onSnapshot(q, snap => {
      const now = Date.now();
      setStatuses(snap.docs.map(d => ({ id: d.id, ...d.data() })).filter(x => {
        const e = x.expiresAt?.toDate ? x.expiresAt.toDate() : new Date(x.expiresAt || 0);
        return e.getTime() > now;
      }));
    }, e => onNotify(`Status sync error: ${e.message}`));
  }, [onNotify]);

  async function publish() {
    if (publishing || (!text.trim() && !file)) return;
    setPublishing(true);
    try {
      let url = "";
      let type = "text";
      if (file) {
        const safe = file.name.replace(/[^a-zA-Z0-9._-]/g, "_");
        const r = ref(storage, `statuses/${currentUid}/${Date.now()}_${safe}`);
        const up = await uploadBytes(r, file, { contentType: file.type || "application/octet-stream" });
        url = await getDownloadURL(up.ref);
        type = file.type.startsWith("video/") ? "video" : "image";
      }
      await addDoc(collection(db, "statuses"), {
        uid: currentUid,
        name: profile.name || "User",
        photo: profile.photo || "",
        text: text.trim(),
        url,
        type,
        createdAt: serverTimestamp(),
        expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000),
        views: [],
        likes: []
      });
      setText(""); setFile(null);
      const el = document.getElementById("status-file"); if (el) el.value = "";
      onNotify("Status added");
    } catch (e) { onNotify(e.message || "Could not add status"); }
    finally { setPublishing(false); }
  }

  async function viewStatus(s) {
    setViewer(s);
    if (!currentUid || s.uid === currentUid || (s.views || []).includes(currentUid)) return;
    try {
      await updateDoc(doc(db, "statuses", s.id), { views: arrayUnion(currentUid) });
    } catch (e) { onNotify(`Could not update views: ${e.message}`); }
  }

  async function toggleLike(s) {
    if (!currentUid) return;
    try {
      const liked = (s.likes || []).includes(currentUid);
      const next = liked ? (s.likes || []).filter(x => x !== currentUid) : [...(s.likes || []), currentUid];
      await updateDoc(doc(db, "statuses", s.id), { likes: next });
      setViewer(v => v && v.id === s.id ? { ...v, likes: next } : v);
    } catch (e) { onNotify(`Like failed: ${e.message}`); }
  }

  async function deleteStatus(s) {
    if (s.uid !== currentUid) return;
    try { await deleteDoc(doc(db, "statuses", s.id)); setViewer(null); onNotify("Status deleted"); }
    catch (e) { onNotify(`Delete failed: ${e.message}`); }
  }

  async function replyToStatus(s, value) {
    const reply = value.trim(); if (!reply) return;
    try {
      await addDoc(collection(db, "statuses", s.id, "replies"), {
        uid: currentUid, name: profile.name || "User", photo: profile.photo || "", text: reply, createdAt: serverTimestamp()
      });
      onNotify("Reply sent");
      return true;
    } catch (e) { onNotify(`Reply failed: ${e.message}`); return false; }
  }

  return <section className="screen updates-screen">
    <header><h1>Updates</h1><div className="head-actions"><button onClick={() => document.getElementById("status-file")?.click()}>＋</button></div></header>
    <div className="my-status">
      <div className="avatar">{profile.photo ? <img src={profile.photo} alt="" /> : String(profile.name || "U").slice(0, 1)}</div>
      <div><b>My status</b><small>Add a photo, video or text</small></div>
      <span className="status-count">{statuses.filter(s => s.uid === currentUid).length}</span>
    </div>
    <div className="status-composer">
      <input value={text} onChange={e => setText(e.target.value)} placeholder="Type a status" />
      <input id="status-file" hidden type="file" accept="image/*,video/*" onChange={e => setFile(e.target.files?.[0] || null)} />
      {file && <small className="selected-file">{file.name}</small>}
      <button className="green" disabled={publishing} onClick={publish}>{publishing ? "Posting…" : "Post"}</button>
    </div>
    <h3>Recent updates</h3>
    {statuses.length === 0 ? <div className="empty">No status updates yet.</div> : statuses.map(s => {
      const views = s.views || [];
      const likes = s.likes || [];
      return <button className="status-card" key={s.id} onClick={() => viewStatus(s)}>
        <div className="avatar">{s.photo ? <img src={s.photo} alt="" /> : String(s.name || "U").slice(0, 1)}</div>
        <div className="status-card-main"><b>{s.name || "User"}</b><small>{s.text || (s.type === "video" ? "Video status" : "Photo status")}</small><small className="status-meta">{views.length} seen · {likes.length} likes</small></div>
        <time>{formatTime(s.createdAt)}</time>
      </button>;
    })}
    {viewer && <div className="status-viewer" onClick={() => setViewer(null)}>
      <div className="status-view" onClick={e => e.stopPropagation()}>
        <div className="status-view-head">
          <div><b>{viewer.name}</b><small>{viewer.views?.length || 0} seen</small></div>
          <button onClick={() => setViewer(null)}>×</button>
        </div>
        {viewer.type === "image" && viewer.url ? <img src={viewer.url} alt="Status" /> : viewer.type === "video" && viewer.url ? <video src={viewer.url} controls autoPlay playsInline /> : <div className="status-text">{viewer.text}</div>}
        {viewer.text && viewer.url ? <p>{viewer.text}</p> : null}
        <div className="status-actions">
          <button className={(viewer.likes || []).includes(currentUid) ? "liked" : ""} onClick={() => toggleLike(viewer)}>♥ {(viewer.likes || []).length}</button>
          <span>👁 {(viewer.views || []).length}</span>
          {viewer.uid === currentUid && <button onClick={() => deleteStatus(viewer)}>Delete</button>}
        </div>
        <div className="status-reply-row">
          <input placeholder="Reply to status" onKeyDown={async e => { if (e.key === "Enter" && e.currentTarget.value.trim()) { const ok = await replyToStatus(viewer, e.currentTarget.value); if (ok) e.currentTarget.value = ""; } }} />
          <button onClick={async e => { const input = e.currentTarget.previousElementSibling; if (input?.value.trim()) { const ok = await replyToStatus(viewer, input.value); if (ok) input.value = ""; } }}>➤</button>
        </div>
      </div>
    </div>}
  </section>;
}
function Communities({ onNotify }) { const [name,setName]=useState("");const [list,setList]=useState([]);useEffect(()=>onSnapshot(query(collection(db,"communities"),orderBy("createdAt","desc"),limit(30)),s=>setList(s.docs.map(d=>({id:d.id,...d.data()}))),()=>{}),[]);async function create(){if(!name.trim())return;try{await addDoc(collection(db,"communities"),{name:name.trim(),owner:auth.currentUser.uid,createdAt:serverTimestamp(),members:[auth.currentUser.uid]});setName("");onNotify("Community created");}catch(e){onNotify(e.message)}}return <section className="screen"><header><h1>Communities</h1></header><div className="community-create"><input value={name} onChange={e=>setName(e.target.value)} placeholder="Community name"/><button className="green" onClick={create}>Create</button></div>{list.length?list.map(c=><div className="community-row" key={c.id}><div className="avatar">♟</div><b>{c.name}</b></div>):<div className="community">No communities yet.</div>}</section>; }

function Bottom({ page, setPage }) { return <nav>{[["chats","▱","Chats"],["updates","◉","Updates"],["communities","♟","Communities"],["calls","☎","Calls"]].map(([p,i,l]) => <button className={page === p ? "navactive" : ""} key={p} onClick={() => setPage(p)}><i>{i}</i><span>{l}</span></button>)}</nav>; }

function SideMenu({ close, setPage, notify }) {
  const items = [
    ["New group", "Group creator opened"],
    ["New community", "Community creator opened"],
    ["Broadcast lists", "Broadcast lists opened"],
    ["Linked devices", "Linked devices opened"],
    ["Starred", "Starred messages opened"],
    ["Payments", "Payments opened"],
    ["Read all", "All chats marked read"],
  ];
  return <div className="overlay" onClick={close}><aside onClick={(e) => e.stopPropagation()}><button className="close" onClick={close}>×</button>{items.map(([label, message]) => <button key={label} onClick={() => { close(); notify(message); }}>{label}</button>)}<hr /><button onClick={() => { close(); setPage("settings"); }}>Settings</button></aside></div>;
}

function Settings({ profile, onBack, onProfile, onPrivacy, onChats, onOpen, onNotify, onLogout }) {
  const rows = [
    ["◇", "Subscriptions", "subscriptions"],
    ["▣", "Linked devices", "linked-devices"],
    ["⚿", "Account", "account"],
    ["♙", "Privacy", "privacy"],
    ["👥", "Friends", "friends"],
    ["▤", "Lists", "lists"],
    ["▱", "Chats", "chats"],
    ["◉", "Appearance", "appearance"],
    ["◌", "Broadcasts", "broadcasts"],
    ["♧", "Notifications", "notifications"],
    ["◔", "Storage and data", "storage"],
    ["♙", "Parental controls", "parental"],
    ["♿", "Accessibility", "accessibility"],
    ["◎", "App language", "language"],
    ["?", "Help and feedback", "help"],
    ["♧", "Invite a friend", "invite"],
    ["∞", "Accounts Centre", "accounts-centre"],
  ];
  return <section className="screen settings-screen">
    <div className="backbar"><button onClick={onBack}>‹</button><h1>Settings</h1></div>
    <button className="settings-profile" onClick={onProfile}><div className="avatar">{profile.photo ? <img src={profile.photo} /> : profile.name?.[0] || "R"}</div><div><b>{profile.name || "RIGHT"}</b><small>@{profile.username || "no_name_12345"}</small></div></button>
    <button className="friend-code-row" onClick={() => navigator.clipboard?.writeText(profile.friendCode || "").then(() => onNotify("6-digit friend code copied"))}><div><span>🔢</span><b>Friend code</b><strong>{profile.friendCode || "------"}</strong></div><em>⧉</em></button>
    {rows.map(([ic,l,route]) => <button className="setting-row setting-row-big" key={l} onClick={() => route === "privacy" ? onPrivacy() : route === "chats" ? onChats() : route === "friends" ? onOpen("friends") : onOpen(`settings-${route}`)}><i>{ic}</i><span><b>{l}</b></span><em>›</em></button>)}
    <button className="danger-row" onClick={onLogout}>Sign out</button>
  </section>;
}

function SettingsDetail({ type, settings, updateSettings, profile, onBack, onNotify }) {
  const titles = { subscriptions:"Subscriptions", "linked-devices":"Linked devices", account:"Account", lists:"Lists", chats:"Chats", appearance:"Appearance", broadcasts:"Broadcasts", notifications:"Notifications", storage:"Storage and data", parental:"Parental controls", accessibility:"Accessibility", language:"App language", help:"Help and feedback", invite:"Invite a friend", "accounts-centre":"Accounts Centre" };
  const title = titles[type] || "Settings";
  const toggle = (key, label, description) => <div className="setting-row"><i>◉</i><span><b>{label}</b><small>{description}</small></span><button className={`toggle ${settings[key] ? "on" : ""}`} onClick={() => updateSettings({ [key]: !settings[key] })}><i /></button></div>;
  if (type === "appearance") return <section className="screen"><Back title={title} onBack={onBack}/><h3>Theme</h3>{["system","light","dark"].map(v => <button className="setting-row" key={v} onClick={() => updateSettings({theme:v})}><i>◉</i><span><b>{v[0].toUpperCase()+v.slice(1)}</b><small>{settings.theme === v ? "Selected" : "Tap to use"}</small></span><em>{settings.theme === v ? "✓" : ""}</em></button>)}{toggle("largeText","Larger text","Increase interface text size")}{toggle("reducedMotion","Reduce motion","Use fewer animations")}</section>;
  if (type === "notifications") return <section className="screen"><Back title={title} onBack={onBack}/>{toggle("notifications","Notifications","Enable app notifications")}{toggle("messagePreview","Message previews","Show message text in notifications")}{toggle("sounds","Sounds","Play notification sounds")}</section>;
  if (type === "storage") return <section className="screen"><Back title={title} onBack={onBack}/>{toggle("dataSaver","Use less data for calls","Reduce media/call network usage")}{toggle("autoDownloadMedia","Auto-download media","Allow automatic media downloads")}{toggle("mediaVisibility","Media visibility","Show downloaded media in gallery")}</section>;
  if (type === "accessibility") return <section className="screen"><Back title={title} onBack={onBack}/>{toggle("highContrast","High contrast","Increase contrast for controls")}{toggle("largeText","Larger text","Use larger interface text")}{toggle("reducedMotion","Reduce motion","Reduce animations")}</section>;
  if (type === "language") return <section className="screen"><Back title={title} onBack={onBack}/>{["English","Hindi"].map(v => <button className="setting-row" key={v} onClick={() => updateSettings({language:v})}><i>◎</i><span><b>{v}</b><small>{settings.language === v ? "Selected" : "Tap to select"}</small></span><em>{settings.language === v ? "✓" : ""}</em></button>)}</section>;
  if (type === "privacy") return <Privacy lockEnabled={false} setLock={() => {}} onBack={onBack} onNotify={onNotify} settings={settings} updateSettings={updateSettings}/>;
  if (type === "chats") return <section className="screen"><Back title={title} onBack={onBack}/>{toggle("enterToSend","Enter is send","Press Enter to send messages")}{toggle("mediaVisibility","Media visibility","Show received media in gallery")}</section>;
  if (type === "linked-devices") return <section className="screen"><Back title={title} onBack={onBack}/><div className="empty">This browser session is the active web device.<br/><small>Firebase Auth manages the signed-in session. A separate device manager requires an Admin backend to revoke other refresh tokens.</small></div></section>;
  if (type === "subscriptions") return <section className="screen"><Back title={title} onBack={onBack}/><div className="empty">No subscription provider is connected yet.<br/><small>Connect Stripe/Google Play/App Store billing credentials to enable paid subscriptions.</small></div></section>;
  if (type === "accounts-centre") return <section className="screen"><Back title={title} onBack={onBack}/><div className="empty">Accounts Centre is external to this Firebase app.<br/><button className="green compact" onClick={() => window.open("https://accountscenter.meta.com/", "_blank", "noopener,noreferrer")}>Open Meta Accounts Centre</button></div></section>;
  if (type === "help") return <section className="screen"><Back title={title} onBack={onBack}/><button className="setting-row" onClick={() => window.open("https://faq.whatsapp.com/", "_blank", "noopener,noreferrer")}><i>?</i><span><b>Help centre</b><small>Open official WhatsApp Help Centre</small></span><em>↗</em></button><button className="setting-row" onClick={() => onNotify(`App: ${navigator.userAgent}`)}><i>ⓘ</i><span><b>Diagnostics</b><small>Show browser diagnostics</small></span><em>›</em></button></section>;
  if (type === "invite") return <section className="screen"><Back title={title} onBack={onBack}/><div className="empty"><button className="green compact" onClick={async()=>{const text=location.origin; try { if(navigator.share) await navigator.share({title:"AI Master",text, url:text}); else {await navigator.clipboard?.writeText(text); onNotify("Invite link copied");} } catch {} }}>Invite</button></div></section>;
  if (type === "account") return <section className="screen"><Back title={title} onBack={onBack}/><div className="empty">Account profile is managed from your Profile screen.</div></section>;
  if (type === "lists" || type === "broadcasts" || type === "parental") return <section className="screen"><Back title={title} onBack={onBack}/><div className="empty">This section is ready for Firebase data. The current build stores UI preferences locally; contact/group list and broadcast delivery need their corresponding Firestore collections and server jobs.</div></section>;
  return <section className="screen"><Back title={title} onBack={onBack}/><div className="empty">Settings are available here.</div></section>;
}
function Back({title,onBack}) { return <div className="backbar"><button onClick={onBack}>‹</button><h1>{title}</h1></div>; }


function Friends({ me, onBack, onNotify, onOpenChat }) {
  const [tab, setTab] = useState("friends");
  const [search, setSearch] = useState("");
  const [code, setCode] = useState("");
  const [users, setUsers] = useState([]);
  const [codeUser, setCodeUser] = useState(null);
  const [friends, setFriends] = useState([]);
  const [incoming, setIncoming] = useState([]);
  const [outgoing, setOutgoing] = useState([]);
  const [busy, setBusy] = useState("");
  useEffect(() => {
    const q = query(collection(db, "friendships"), where("participants", "array-contains", me.uid));
    return onSnapshot(q, async snap => {
      const rows = snap.docs.map(d => ({ id: d.id, ...d.data() })).filter(x => x.status === "accepted");
      const hydrated = await Promise.all(rows.map(async row => {
        const uid = row.participants.find(x => x !== me.uid); if (!uid) return null;
        const ps = await getDoc(doc(db, "publicProfiles", uid));
        return { ...row, uid, profile: ps.exists() ? ps.data() : { name: "User", photo: "" } };
      })); setFriends(hydrated.filter(Boolean));
    }, e => onNotify(`Friends sync error: ${e.message}`));
  }, [me.uid]);
  useEffect(() => {
    const q = query(collection(db, "friendRequests"), where("toUid", "==", me.uid), where("status", "==", "pending"));
    return onSnapshot(q, async snap => setIncoming(await Promise.all(snap.docs.map(async d => { const x=d.data(); const ps=await getDoc(doc(db,"publicProfiles",x.fromUid)); return {id:d.id,...x,profile:ps.exists()?ps.data():{name:"User",photo:""}}; }))), e => onNotify(`Request sync error: ${e.message}`));
  }, [me.uid]);
  useEffect(() => {
    const q = query(collection(db, "friendRequests"), where("fromUid", "==", me.uid), where("status", "==", "pending"));
    return onSnapshot(q, snap => setOutgoing(snap.docs.map(d => ({id:d.id,...d.data()}))), e => onNotify(`Request sync error: ${e.message}`));
  }, [me.uid]);
  async function searchUsers(value) {
    setSearch(value); const term=value.trim().toLowerCase(); if(!term){setUsers([]);return;}
    try { const q=query(collection(db,"publicProfiles"),where("nameLower",">=",term),where("nameLower","<=",term+"\uf8ff"),limit(30)); const snap=await getDocs(q); setUsers(snap.docs.map(d=>({uid:d.id,...d.data()})).filter(x=>x.uid!==me.uid)); }
    catch { const snap=await getDocs(collection(db,"publicProfiles")); setUsers(snap.docs.map(d=>({uid:d.id,...d.data()})).filter(x=>x.uid!==me.uid&&String(x.name||"").toLowerCase().includes(term)).slice(0,30)); }
  }
  async function findByCode() {
    const value=code.replace(/\D/g,"").slice(0,6); setCode(value); setCodeUser(null); if(value.length!==6) return;
    try { const q=query(collection(db,"publicProfiles"),where("friendCode","==",value),limit(1)); const snap=await getDocs(q); if(!snap.empty && snap.docs[0].id!==me.uid) setCodeUser({uid:snap.docs[0].id,...snap.docs[0].data()}); else onNotify("6-digit code not found"); }
    catch(e){onNotify(e.message||"Could not find user");}
  }
  function relation(uid){ if(friends.some(x=>x.uid===uid)) return "friends"; if(outgoing.some(x=>x.toUid===uid)) return "sent"; if(incoming.some(x=>x.fromUid===uid)) return "incoming"; return "add"; }
  async function sendRequest(other){
    setBusy(other.uid); try { const id=`${me.uid}_${other.uid}`; const reverse=await getDoc(doc(db,"friendRequests",`${other.uid}_${me.uid}`)); if(reverse.exists()&&reverse.data().status==="pending"){await acceptRequest({id:reverse.id,...reverse.data()});return;} await setDoc(doc(db,"friendRequests",id),{fromUid:me.uid,toUid:other.uid,status:"pending",createdAt:serverTimestamp(),updatedAt:serverTimestamp()},{merge:true}); onNotify("Friend request sent"); } catch(e){onNotify(e.message||"Could not send request");} finally{setBusy("");}
  }
  async function acceptRequest(req){setBusy(req.id);try{const participants=[req.fromUid,req.toUid].sort();const batch=writeBatch(db);batch.set(doc(db,"friendships",participants.join("_")),{participants,status:"accepted",createdAt:req.createdAt||serverTimestamp(),updatedAt:serverTimestamp()},{merge:true});batch.update(doc(db,"friendRequests",req.id),{status:"accepted",updatedAt:serverTimestamp()});await batch.commit();onNotify("Friend request accepted");}catch(e){onNotify(e.message||"Could not accept request");}finally{setBusy("");}}
  async function rejectRequest(req){try{await updateDoc(doc(db,"friendRequests",req.id),{status:"rejected",updatedAt:serverTimestamp()});onNotify("Request declined");}catch(e){onNotify(e.message||"Could not decline request");}}
  async function openFriend(friend){setBusy(friend.uid);try{const other={uid:friend.uid,name:friend.profile?.name||"User",photo:friend.profile?.photo||""};const id=chatIdFor(me.uid,other.uid);await ensureChat(id,{uid:me.uid,name:me.name,photo:me.photo},other);onOpenChat({id,other});}catch(e){onNotify(e.message||"Could not open chat");}finally{setBusy("");}}
  const codeCard=codeUser && <div className="friend-code-result"><div className="avatar">{codeUser.photo?<img src={codeUser.photo}/>:String(codeUser.name||"U").slice(0,1)}</div><div className="friend-info"><b>{codeUser.name||"User"}</b><small>@{codeUser.username||"AI Master user"}</small></div>{relation(codeUser.uid)==="add"?<button className="green friend-chat-btn" onClick={()=>sendRequest(codeUser)}>Add</button>:<span className="request-state">{relation(codeUser.uid)}</span>}</div>;
  return <section className="screen friends-screen"><div className="backbar"><button onClick={onBack}>‹</button><h1>Friends</h1></div><div className="friends-tabs"><button className={tab==="friends"?"active":""} onClick={()=>setTab("friends")}>Friends ({friends.length})</button><button className={tab==="requests"?"active":""} onClick={()=>setTab("requests")}>Requests {incoming.length?`(${incoming.length})`:""}</button><button className={tab==="code"?"active":""} onClick={()=>setTab("code")}>6-digit code</button><button className={tab==="find"?"active":""} onClick={()=>setTab("find")}>Find</button></div>
  {tab==="friends" && <div className="friends-list">{friends.length===0?<div className="empty">No friends yet.</div>:friends.map(f=><div className="friend-card" key={f.uid}><div className="avatar">{f.profile?.photo?<img src={f.profile.photo}/>:String(f.profile?.name||"U").slice(0,1)}</div><div className="friend-info"><b>{f.profile?.name||"User"}</b><small>{f.profile?.username?`@${f.profile.username}`:"AI Master user"}</small></div><button className="green friend-chat-btn" onClick={()=>openFriend(f)}>Chat</button><button className="icon-btn" title="Voice call" onClick={()=>window.dispatchEvent(new CustomEvent("start-firebase-call",{detail:{other:{uid:f.uid,name:f.profile?.name||"User",photo:f.profile?.photo||""},kind:"audio"}}))}>☎</button><button className="icon-btn" title="Video call" onClick={()=>window.dispatchEvent(new CustomEvent("start-firebase-call",{detail:{other:{uid:f.uid,name:f.profile?.name||"User",photo:f.profile?.photo||""},kind:"video"}}))}>▣</button></div>)}</div>}
  {tab==="requests" && <div className="friends-list">{incoming.length===0?<div className="empty">No pending requests.</div>:incoming.map(r=><div className="friend-card" key={r.id}><div className="avatar">{r.profile?.photo?<img src={r.profile.photo}/>:String(r.profile?.name||"U").slice(0,1)}</div><div className="friend-info"><b>{r.profile?.name||"User"}</b><small>Friend request</small></div><div className="request-actions"><button className="green" onClick={()=>acceptRequest(r)}>Accept</button><button onClick={()=>rejectRequest(r)}>Decline</button></div></div>)}</div>}
  {tab==="code" && <div className="friends-find"><div className="my-code-card"><small>MY 6-DIGIT FRIEND CODE</small><strong>{me.friendCode||"------"}</strong></div><input inputMode="numeric" maxLength={6} value={code} onChange={e=>{setCode(e.target.value.replace(/\D/g,"").slice(0,6));setCodeUser(null)}} onKeyDown={e=>e.key==="Enter"&&findByCode()} placeholder="Enter 6-digit friend code"/><button className="green" onClick={findByCode}>Find user</button>{codeCard}</div>}
  {tab==="find" && <div className="friends-find"><input value={search} onChange={e=>searchUsers(e.target.value)} placeholder="Search by name"/>{search.trim()&&users.length===0?<div className="empty small-empty">No users found.</div>:users.map(u=><div className="friend-card" key={u.uid}><div className="avatar">{u.photo?<img src={u.photo}/>:String(u.name||"U").slice(0,1)}</div><div className="friend-info"><b>{u.name||"User"}</b><small>{u.username?`@${u.username}`:"AI Master user"}</small></div>{relation(u.uid)==="add"?<button className="green friend-chat-btn" onClick={()=>sendRequest(u)}>Add</button>:<span className="request-state">{relation(u.uid)}</span>}</div>)}</div>}
  </section>;
}

function Profile({ profile, user, onBack, onSave, fileRef, setCropSrc, setShowCrop, showCrop, cropSrc }) {
  const [p, setP] = useState(profile);
  const [zoom, setZoom] = useState(1);
  const [crop, setCrop] = useState({ x: 0, y: 0 });
  const [area, setArea] = useState(null);
  const [savingPhoto, setSavingPhoto] = useState(false);
  useEffect(() => setP(profile), [profile]);

  async function change(k, v) {
    const next = { ...p, [k]: v };
    setP(next);
    try { await onSave(next); } catch (e) { alert(e?.message || "Profile save failed"); }
  }

  function file(e) {
    const f = e.target.files?.[0];
    if (!f) return;
    if (f.size > 10 * 1024 * 1024) {
      alert("Photo must be 10 MB or smaller.");
      e.target.value = "";
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      setCropSrc(reader.result);
      setShowCrop(true);
      setZoom(1);
      setCrop({ x: 0, y: 0 });
      setArea(null);
    };
    reader.onerror = () => alert("Could not read this photo.");
    reader.readAsDataURL(f);
    e.target.value = "";
  }

  async function cropAndSave() {
    if (!area || savingPhoto) return;
    setSavingPhoto(true);
    try {
      const dataUrl = await getCroppedImage(cropSrc, area);
      let finalUrl = dataUrl;

      if (user) {
        // Use a new filename on every upload so the browser cannot keep showing
        // an old cached avatar URL. The 512px compressed JPEG is also much faster
        // than uploading the original phone photo.
        const storageRef = ref(storage, `users/${user.uid}/profile/avatar.jpg`);
        const blob = await (await fetch(dataUrl)).blob();
        await uploadBytes(storageRef, blob, { contentType: "image/jpeg", cacheControl: "public,max-age=3600" });
        finalUrl = `${await getDownloadURL(storageRef)}&v=${Date.now()}`;
      }

      const next = { ...p, photo: finalUrl };
      setP(next);
      // Save the URL directly; don't route the upload through a second slow UI update.
      await onSave(next);
      setShowCrop(false);
      setCropSrc("");
    } catch (e) {
      alert(`Photo save failed: ${e?.message || "Please try again."}`);
    } finally {
      setSavingPhoto(false);
    }
  }

  return <section className="screen">
    <div className="backbar"><button onClick={onBack}>‹</button><h1>Profile</h1></div>
    <div className="profile-head">
      <div className="profile-photo-wrap"><button className="profile-photo" onClick={() => fileRef.current?.click()} aria-label="Change profile photo">{p.photo ? <img src={p.photo} alt="Profile" /> : <span>{p.name?.[0] || "R"}</span>}<span className="profile-camera">📷</span></button></div>
      <label className="green compact">Upload / change photo
        <input ref={fileRef} hidden type="file" accept="image/jpeg,image/png,image/webp,image/*" onChange={file} />
      </label>
    </div>
    <div className="friend-code-profile"><span>6-digit Friend Code</span><strong>{p.friendCode || "------"}</strong></div>
    <div className="form">
      [["name","Name","RIGHT"],["about","About","Set About"],["username","Username","no_name_12345"],["phone","Phone",user?.phoneNumber || "+91…"],["links","Links","Add links"]].map(([k,l,ph]) =>
        <label key={k}>{l}<input value={p[k] || ""} placeholder={ph} onChange={(e) => change(k, e.target.value)} /></label>
      )}
    </div>
    {showCrop && <div className="crop-modal">
      <div className="crop-box">
        <div className="cropper"><Cropper image={cropSrc} crop={crop} zoom={zoom} aspect={1} onCropChange={setCrop} onZoomChange={setZoom} onCropComplete={(_, a) => setArea(a)} /></div>
        <input type="range" min="1" max="3" step=".05" value={zoom} onChange={(e) => setZoom(Number(e.target.value))} />
        <button className="green" disabled={savingPhoto || !area} onClick={cropAndSave}>
          {savingPhoto ? "Saving photo…" : "Crop & save"}
        </button>
        <button disabled={savingPhoto} onClick={() => { setShowCrop(false); setCropSrc(""); }}>Cancel</button>
      </div>
    </div>}
  </section>;
}


async function getCroppedImage(src, pixelCrop) {
  const image = await new Promise((resolve, reject) => {
    const im = new Image();
    im.onload = () => resolve(im);
    im.onerror = () => reject(new Error("Image could not be decoded"));
    im.src = src;
  });
  const size = Math.max(1, Math.min(pixelCrop.width, pixelCrop.height));
  const canvas = document.createElement("canvas");
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext("2d", { alpha: false });
  if (!ctx) throw new Error("Canvas is not supported by this browser");
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = "high";
  ctx.drawImage(image, pixelCrop.x, pixelCrop.y, size, size, 0, 0, 512, 512);
  return canvas.toDataURL("image/jpeg", 0.82);
}

function Privacy({ lockEnabled, setLock, onBack, onNotify, settings = {}, updateSettings }) { return <section className="screen"><div className="backbar"><button onClick={onBack}>‹</button><h1>Privacy</h1></div><h3>Privacy</h3><div className="setting-row"><i>◉</i><span><b>Last seen</b><small>{settings.lastSeen || "Everyone"}</small></span><select value={settings.lastSeen || "Everyone"} onChange={e => updateSettings?.({lastSeen:e.target.value})}><option>Everyone</option><option>My contacts</option><option>Nobody</option></select></div><div className="setting-row"><i>◉</i><span><b>Profile photo</b><small>{settings.profilePhotoVisibility || "Everyone"}</small></span><select value={settings.profilePhotoVisibility || "Everyone"} onChange={e => updateSettings?.({profilePhotoVisibility:e.target.value})}><option>Everyone</option><option>My contacts</option><option>Nobody</option></select></div><div className="setting-row"><i>✓</i><span><b>Read receipts</b><small>Show when messages are read</small></span><button className={`toggle ${settings.readReceipts !== false ? "on" : ""}`} onClick={() => updateSettings?.({readReceipts: settings.readReceipts === false})}><i /></button></div><h3>Security</h3><div className="setting-row"><i>🔒</i><span><b>App lock</b><small>Fingerprint, face or device credential</small></span><button className={`toggle ${lockEnabled ? "on" : ""}`} onClick={() => setLock(!lockEnabled)}><i></i></button></div></section>; }
function ChatSettings({ lockEnabled, setLock, onBack, onNotify }) { return <section className="screen"><div className="backbar"><button onClick={onBack}>‹</button><h1>Chats</h1></div><button className="setting-row" onClick={() => onNotify("Chat backup opened")}><i>☁</i><span><b>Chat backup</b><small>Cloud backup</small></span><em>›</em></button><button className="setting-row" onClick={() => onNotify("Chat history opened")}><i>▱</i><span><b>Chat history</b><small>Manage chat history</small></span><em>›</em></button><div className="setting-row"><i>🔐</i><span><b>Chat lock</b><small>Protect chats with device security</small></span><button className={`toggle ${lockEnabled ? "on" : ""}`} onClick={() => setLock(!lockEnabled)}><i></i></button></div></section>; }

function MetaAI({ messages, setMessages, text, setText, busy, setBusy, onBack }) {
  const [calling, setCalling] = useState(false);
  const [listening, setListening] = useState(false);
  const recognitionRef = useRef(null);
  const [voice, setVoice] = useState("");
  const [voices, setVoices] = useState([]);

  useEffect(() => {
    const load = () => setVoices(window.speechSynthesis?.getVoices?.() || []);
    load(); window.speechSynthesis?.addEventListener?.("voiceschanged", load);
    return () => window.speechSynthesis?.removeEventListener?.("voiceschanged", load);
  }, []);
  function speak(content) {
    if (!window.speechSynthesis) return;
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(content);
    const chosen = voices.find(v => v.name === voice) || voices.find(v => /^hi(-|_)/i.test(v.lang)) || voices[0];
    if (chosen) u.voice = chosen;
    u.rate = 0.98; u.pitch = 1;
    window.speechSynthesis.speak(u);
  }
  async function ask(t, speakReply = false) {
    const clean = String(t || "").trim();
    if (!clean || busy) return;
    const next = [...messages, { role: "user", content: clean }];
    setMessages(next); setText(""); setBusy(true);
    try {
      const response = await fetch("/api/meta-ai", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ messages: next.slice(-20) }) });
      const body = await response.json();
      if (!response.ok) throw new Error(body.error || "AI request failed");
      setMessages([...next, { role: "assistant", content: body.content }]);
      if (speakReply) speak(body.content);
    } catch (e) {
      const err = `AI connection error: ${e.message}. Check the Netlify API key and redeploy if needed.`;
      setMessages([...next, { role: "assistant", content: err }]);
      if (speakReply) speak(err);
    } finally { setBusy(false); }
  }
  function toggleCall() {
    if (calling) {
      recognitionRef.current?.stop?.(); window.speechSynthesis?.cancel?.(); setCalling(false); setListening(false); return;
    }
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) { alert("Voice call needs Chrome/Android speech recognition support."); return; }
    const rec = new SR(); rec.lang = /Hindi|Hinglish/i.test(navigator.language) ? "hi-IN" : "en-IN"; rec.interimResults = false; rec.continuous = true;
    rec.onstart = () => { setCalling(true); setListening(true); };
    rec.onend = () => { if (calling) { try { rec.start(); } catch {} } else setListening(false); };
    rec.onerror = () => setListening(false);
    rec.onresult = e => { const last = e.results[e.results.length - 1]?.[0]?.transcript || ""; if (last.trim()) ask(last, true); };
    recognitionRef.current = rec;
    try { rec.start(); setCalling(true); } catch { alert("Could not start microphone."); }
  }
  return <section className="screen ai-screen">
    <div className="backbar"><button onClick={onBack}>‹</button><h1>Meta AI ✓</h1><button className={`ai-call-btn ${calling ? "active" : ""}`} onClick={toggleCall}>{calling ? "■" : "☎"}</button><a href="https://www.meta.ai/" target="_blank" rel="noreferrer">↗</a></div>
    {calling && <div className="ai-call-status"><div className="ai-avatar big">✦</div><b>Meta AI voice call</b><small>{listening ? "Listening… speak now" : "Connecting…"}</small><button onClick={toggleCall}>End call</button></div>}
    <div className="ai-messages">
      {messages.length === 0 ? (
        <div className="empty">Meta AI chat<br /><small>Uses your configured Meta model API through Netlify.</small></div>
      ) : null}
      {messages.map((m, i) => (
        <div key={i} className={`bubble ${m.role}`}>
          <div>{m.content}</div>
          {m.role === "assistant" ? (
            <button className="speak-btn" onClick={() => speak(m.content)}>🔊</button>
          ) : null}
        </div>
      ))}
      {busy ? <div className="bubble assistant">Thinking…</div> : null}
    </div>
    <div className="ai-input"><button className="plus-ai" onClick={() => document.getElementById("meta-ai-file")?.click()}>＋</button><input id="meta-ai-file" hidden type="file" accept="image/*,.pdf,.txt,.doc,.docx" onChange={e => { const f=e.target.files?.[0]; if(f) setText(t => `${t ? t+"\n" : ""}[Attached: ${f.name}]`); e.target.value=""; }} /><button className="ai-voice-small" onClick={() => { const SR=window.SpeechRecognition||window.webkitSpeechRecognition; if(!SR){alert("Voice input is not supported in this browser.");return;} const r=new SR(); r.lang="hi-IN"; r.onresult=e=>setText(e.results[0][0].transcript); r.start(); }}>🎙</button><input value={text} onChange={(e) => setText(e.target.value)} onKeyDown={(e) => e.key === "Enter" && ask(text)} placeholder="Message Meta AI" /><select value={voice} onChange={e => setVoice(e.target.value)} aria-label="Voice"><option value="">Voice</option>{voices.slice(0,30).map(v => <option key={v.name} value={v.name}>{v.name}</option>)}</select><button onClick={() => ask(text)} disabled={busy}>➤</button></div>
  </section>;
}

createRoot(document.getElementById("root")).render(<App />);
