import { initializeApp } from "firebase/app";
import { getAnalytics, isSupported as analyticsSupported } from "firebase/analytics";
import {
  getAuth,
  RecaptchaVerifier,
  signInWithPhoneNumber,
  onAuthStateChanged,
  signOut,
  signInAnonymously,
} from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";
import { getDatabase } from "firebase/database";

// Firebase Web configuration supplied for project: meseage-60483.
// Firebase Web config values are client-side identifiers; the real security boundary
// is Firebase Authentication + Firestore/Storage Security Rules.
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || "AIzaSyBrPv8bfd05MMva3MWHZ9BnyWweLQekKV4",
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || "meseage-60483.firebaseapp.com",
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || "meseage-60483",
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || "meseage-60483.firebasestorage.app",
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || "632698731957",
  appId: import.meta.env.VITE_FIREBASE_APP_ID || "1:632698731957:web:08cb3cf1c69fe10a55adfc",
  measurementId: import.meta.env.VITE_FIREBASE_MEASUREMENT_ID || "G-RSJHRE4J2C",
  databaseURL: import.meta.env.VITE_FIREBASE_DATABASE_URL || "https://meseage-60483-default-rtdb.firebaseio.com",
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
const storage = getStorage(app);
const databaseUrl = import.meta.env.VITE_FIREBASE_DATABASE_URL || undefined;
const database = databaseUrl ? getDatabase(app, databaseUrl) : getDatabase(app);

// Analytics is optional. Auth/Firestore/Storage continue to work if Analytics is
// unavailable in a browser, privacy mode, or local development environment.
let analytics = null;
if (typeof window !== "undefined") {
  analyticsSupported()
    .then((supported) => {
      if (supported) analytics = getAnalytics(app);
    })
    .catch(() => {});
}

export {
  app,
  auth,
  db,
  storage,
  database,
  analytics,
  firebaseConfig,
  RecaptchaVerifier,
  signInWithPhoneNumber,
  onAuthStateChanged,
  signOut,
  signInAnonymously,
};
