import { onRequest } from 'firebase-functions/v2/https';
import { defineSecret } from 'firebase-functions/params';
import { setGlobalOptions } from 'firebase-functions/v2/options';

setGlobalOptions({ region: 'asia-south1', maxInstances: 10 });

const llamaKey = defineSecret('META_MODEL_API_KEY');
const API_URL = process.env.META_MODEL_API_URL || 'https://api.llama.com/v1/chat/completions';
const MODEL = process.env.META_MODEL_NAME || 'Llama-4-Maverick-17B-128E-Instruct-FP8';

function json(res, status, data) {
  res.status(status).set('Content-Type', 'application/json; charset=utf-8').send(data);
}

async function handler(req, res) {
  if (req.method === 'OPTIONS') return res.status(204).send('');
  if (req.method !== 'POST') return json(res, 405, { error: 'Method not allowed' });
  try {
    const key = llamaKey.value();
    if (!key) return json(res, 503, { error: 'Meta/Llama API key is not configured on the server.' });
    const messages = Array.isArray(req.body?.messages)
      ? req.body.messages.filter(m => ['user', 'assistant', 'developer', 'system'].includes(m?.role) && typeof m?.content === 'string').slice(-20)
      : [];
    if (!messages.length) return json(res, 400, { error: 'No chat messages supplied.' });
    const upstream = await fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${key}` },
      body: JSON.stringify({ model: MODEL, messages, max_completion_tokens: 1024, temperature: 0.7 }),
    });
    const raw = await upstream.text();
    let body;
    try { body = JSON.parse(raw); } catch { body = { raw }; }
    if (!upstream.ok) {
      const detail = body?.error?.message || body?.message || body?.raw || `HTTP ${upstream.status}`;
      return json(res, upstream.status, { error: String(detail).slice(0, 700) });
    }
    const content = body?.choices?.[0]?.message?.content ?? body?.completion_message?.content?.text ?? body?.completion_message?.content ?? body?.output?.text;
    if (typeof content !== 'string') return json(res, 502, { error: 'Meta/Llama API returned no assistant text.' });
    return json(res, 200, { content, model: MODEL });
  } catch (error) {
    return json(res, 500, { error: error?.message || 'AI request failed' });
  }
}

export const metaAI = onRequest({ secrets: [llamaKey], invoker: 'public' }, handler);
export const metaHealth = onRequest({ secrets: [llamaKey], invoker: 'public' }, (req, res) => json(res, 200, { ok: true, metaConfigured: Boolean(llamaKey.value()), model: MODEL }));
