const API_URL = process.env.META_MODEL_API_URL || 'https://api.llama.com/v1/chat/completions';
const MODEL = process.env.META_MODEL_NAME || 'Llama-4-Maverick-17B-128E-Instruct-FP8';

export default async function handler(req, res) {
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  const key = process.env.META_MODEL_API_KEY || process.env.MODEL_API_KEY;
  if (!key) return res.status(503).json({ error: 'Meta/Llama API key is not configured on Vercel.' });
  try {
    const messages = Array.isArray(req.body?.messages)
      ? req.body.messages.filter(m => ['user','assistant','developer','system'].includes(m?.role) && typeof m?.content === 'string').slice(-20)
      : [];
    if (!messages.length) return res.status(400).json({ error: 'No chat messages supplied.' });
    const upstream = await fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${key}` },
      body: JSON.stringify({ model: MODEL, messages, max_completion_tokens: 1024, temperature: 0.7, stream: false })
    });
    const raw = await upstream.text();
    let body; try { body = JSON.parse(raw); } catch { body = { raw }; }
    if (!upstream.ok) {
      const detail = body?.error?.message || body?.message || body?.raw || `HTTP ${upstream.status}`;
      return res.status(upstream.status).json({ error: String(detail).slice(0, 700) });
    }
    const content = body?.choices?.[0]?.message?.content ?? body?.completion_message?.content?.text ?? body?.completion_message?.content ?? body?.output?.text;
    if (typeof content !== 'string') return res.status(502).json({ error: 'Meta/Llama API returned no assistant text.' });
    return res.status(200).json({ content, model: MODEL });
  } catch (e) {
    return res.status(500).json({ error: e?.message || 'AI request failed' });
  }
}
