export default function handler(req, res) {
  const key = process.env.META_MODEL_API_KEY || process.env.MODEL_API_KEY;
  res.status(200).json({ ok: true, metaConfigured: Boolean(key), model: process.env.META_MODEL_NAME || 'Llama-4-Maverick-17B-128E-Instruct-FP8' });
}
