import http from "http";
import dotenv from "dotenv";

dotenv.config();
const port = Number(process.env.PORT || 8787);
const META_API_URL = process.env.META_MODEL_API_URL || "https://api.llama.com/v1/chat/completions";
const META_MODEL = process.env.META_MODEL_NAME || "Llama-4-Maverick-17B-128E-Instruct-FP8";
const META_KEY = process.env.META_MODEL_API_KEY || process.env.MODEL_API_KEY;

function send(res, status, data) {
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "POST, GET, OPTIONS",
  });
  res.end(JSON.stringify(data));
}

async function readBody(req) {
  let raw = "";
  for await (const chunk of req) {
    raw += chunk;
    if (raw.length > 256_000) throw new Error("Request too large");
  }
  return JSON.parse(raw || "{}");
}

async function metaAI(messages) {
  if (!META_KEY) throw new Error("Meta Model API key is not configured. Add META_MODEL_API_KEY to server .env.");
  const safeMessages = Array.isArray(messages) ? messages.filter((m) => ["user", "assistant", "developer", "system"].includes(m?.role) && typeof m?.content === "string").slice(-20) : [];
  if (!safeMessages.length) throw new Error("No chat messages supplied.");

  const response = await fetch(META_API_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${META_KEY}`,
    },
    body: JSON.stringify({
      model: META_MODEL,
      messages: safeMessages,
      stream: false,
    }),
  });
  const raw = await response.text();
  let body;
  try { body = JSON.parse(raw); } catch { body = { raw }; }
  if (!response.ok) {
    const detail = body?.error?.message || body?.message || body?.raw || `HTTP ${response.status}`;
    throw new Error(`Meta Model API ${response.status}: ${String(detail).slice(0, 500)}`);
  }
  const content = body?.choices?.[0]?.message?.content
    ?? body?.completion_message?.content?.text
    ?? body?.completion_message?.content
    ?? body?.output?.text;
  if (typeof content !== "string") throw new Error("Meta/Llama API returned no assistant text.");
  return content;
}

const server = http.createServer(async (req, res) => {
  if (req.method === "OPTIONS") return send(res, 204, {});
  if (req.method === "GET" && req.url === "/api/health") {
    return send(res, 200, { ok: true, metaConfigured: Boolean(META_KEY), model: META_MODEL });
  }
  if (req.method === "POST" && req.url === "/api/meta-ai") {
    try {
      const body = await readBody(req);
      const content = await metaAI(body.messages);
      return send(res, 200, { content, model: META_MODEL });
    } catch (error) {
      return send(res, 500, { error: error.message || "AI request failed" });
    }
  }
  res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
  res.end("Not found");
});

server.listen(port, () => console.log(`Meta AI proxy listening on http://localhost:${port}`));
